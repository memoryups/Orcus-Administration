﻿namespace Orcus.CommandManagement
{
    public class CommandSettings
    {
        public bool AllowMultipleThreads { get; set; }
    }
}