﻿using System;

namespace Orcus.Commands.RemoteDesktop.Capture.DesktopDuplication
{
    public class DesktopDuplicationException : Exception
    {
        public DesktopDuplicationException(string message)
            : base(message) { }
    }
}
