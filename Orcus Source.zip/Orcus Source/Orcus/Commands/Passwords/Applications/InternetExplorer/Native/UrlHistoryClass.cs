using System.Runtime.InteropServices;

namespace Orcus.Commands.Passwords.Applications.InternetExplorer.Native
{
    [ComImport]
    [Guid("3C374A40-BAE4-11CF-BF7D-00AA006946EE")]
    public class UrlHistoryClass
    {
    }
}