﻿namespace Orcus.Shared.Commands.Registry
{
    public enum RegistryHive : byte
    {
        ClassesRoot,
        CurrentUser,
        LocalMachine,
        Users,
        CurrentConfig
    }
}