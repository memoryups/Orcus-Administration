using System.Collections.Generic;

namespace Orcus.Business.Manager.Core.Data
{
    public class DatabaseInfo
    {
        public List<License> licenses { get; set; }
        public List<Computer> computers { get; set; }
    }
}