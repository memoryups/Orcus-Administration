﻿namespace Orcus.Business.Server
{
    public class Program
    {
        static void Main(string[] args)
        {
        }
    }
}