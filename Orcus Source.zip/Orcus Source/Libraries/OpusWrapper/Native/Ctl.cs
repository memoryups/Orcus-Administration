namespace OpusWrapper.Native
{
    public enum Ctl
    {
        SetBitrateRequest = 4002,
        GetBitrateRequest = 4003,
        SetInbandFECRequest = 4012,
        GetInbandFECRequest = 4013
    }
}