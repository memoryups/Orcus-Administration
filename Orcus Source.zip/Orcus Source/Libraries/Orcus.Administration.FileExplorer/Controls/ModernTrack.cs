﻿using System.Windows.Controls;

namespace Orcus.Administration.FileExplorer.Controls
{
    public class ModernTrack : ContentControl
    {
    }
}