﻿namespace ShellDll
{
    public enum KnownFolderFindMode : int
    {
        ExactMatch = 0,
        NearestParentMatch = ExactMatch + 1
    };

}
