﻿namespace ShellDll
{
    public enum KnownFolderCategory
    {
        Virtual = 1,
        Fixed = 2,
        Common = 3,
        PerUser = 4
    }
}
