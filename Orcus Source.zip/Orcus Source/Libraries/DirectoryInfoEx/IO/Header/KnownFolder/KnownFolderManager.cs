﻿using System.Runtime.InteropServices;

namespace ShellDll
{
    [ComImport, Guid("4df0c730-df9d-4ae3-9153-aa6b82e9795a")]
    public class KnownFolderManager
    {
        
    }
}
